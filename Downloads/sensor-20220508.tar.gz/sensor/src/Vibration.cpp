#include "Vibration.h"
#include <iostream>
#include <regex>
#include <cstring> //for memset
#include <cstdlib> //for atoi
#include <curl/curl.h> //for communicate with influxdb

extern std::string BucketName;
extern std::string Authorization;
extern std::string QueryDataURL;

Vibration::Vibration(std::string deviceName){
    memset(&this->info, 0, sizeof(Vibration_t));
    this->deviceName = deviceName;
    this->info.device = deviceName;
    this->historyInfo.push_back(this->info);
}

Vibration::~Vibration(){
}

int Vibration::queryData(float frequency){
    //从数据库中读取数据
    std::cout << this->info.device << " query data" << std::endl;
    CURL *curl;
    CURLcode resCode;
    
    curl = curl_easy_init();
    if(curl) {
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_easy_setopt(curl, CURLOPT_URL, QueryDataURL.c_str());
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl, CURLOPT_DEFAULT_PROTOCOL, "https");
        struct curl_slist *headers = NULL;
        headers = curl_slist_append(headers, "Content-Type: application/vnd.flux");
        headers = curl_slist_append(headers, std::string("Authorization: Token " + Authorization).c_str());
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        char *data = new char[1024];
        sprintf(data, Vibration_Data_Flux, BucketName.c_str(), this->info.device.c_str(), 
            "zdSyZdz", "zdSyZxz", "zdSyFfz", "zdSyPjz", "zdSyJfz", "zdSyYxz", "zdSyQdzb", "zdSyPdzb", 
            "zdSyYdzb", "zdPyPpjz", "zdPyPlzx", "zdPyJfgpl", "zdPyPpjfgz", "zdPyBzcpl","zdYssj", "zdZcxh");
        curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, strlen(data));
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);

        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, this->parseData);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&this->info);
        resCode = curl_easy_perform(curl);
        if(resCode != CURLE_OK){
            fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(resCode));
        }
        curl_slist_free_all(headers); /* free the header list*/
        delete[] data;
    }
    curl_easy_cleanup(curl);
    return 0;
}

int Vibration::queryFaultData(float frequency){ //目前为每隔frequency个数据取一个
    std::cout << this->info.device << " query fault data" << std::endl;
    CURL *curl;
    CURLcode resCode;
    curl = curl_easy_init();
    if(curl) {
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_easy_setopt(curl, CURLOPT_URL, QueryDataURL.c_str());
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl, CURLOPT_DEFAULT_PROTOCOL, "https");
        struct curl_slist *headers = NULL;
        headers = curl_slist_append(headers, "Content-Type: application/vnd.flux");
        headers = curl_slist_append(headers, std::string("Authorization: Token " + Authorization).c_str());
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        char *data = new char[1024];
        sprintf(data, Vibration_Fault_Flux, BucketName.c_str(), (int)frequency, this->info.device.c_str(),
            "zdSyZdz", "zdSyZxz", "zdSyFfz", "zdSyPjz", "zdSyJfz", "zdSyYxz", "zdSyQdzb", "zdSyPdzb", 
            "zdSyYdzb", "zdPyPpjz", "zdPyPlzx", "zdPyJfgpl", "zdPyPpjfgz", "zdPyBzcpl","zdYssj", "zdZcxh");
        curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, strlen(data));
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, this->parseFaultData);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&this->historyRawData);
        resCode = curl_easy_perform(curl);
        if(resCode != CURLE_OK){
            fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(resCode));
        }
        curl_slist_free_all(headers); /* free the header list*/
        delete[] data;
    }
    curl_easy_cleanup(curl);
    /*************************start parse*********************************/
    // std::cout << this->historyRawData << std::endl;
    int field_num = 5;
    std::regex line_re("[\n\r,]");
    std::vector<std::string> v(std::sregex_token_iterator(this->historyRawData.begin(), this->historyRawData.end(), line_re, -1), std::sregex_token_iterator());
    for(size_t i=0; i<v.size(); i++){
        if(v[i].empty())
            v.erase(v.begin()+i--);
    }
    // for(auto&& s: v){
    //     std::cout << "***";
    //     std::cout << s <<  "***" << s.length() << std::endl;
    // }
    std::vector<Vibration_t> * v_dv = &this->historyInfo;

    if(v.empty() || v.size() % field_num != 0){
        if(v.empty())
            printf("未找到设备%s历史数据\n", v_dv->front().device.c_str());
        else 
            printf("%s设备数据格式错误\n", v_dv->front().device.c_str());
        return -1;
    }
    int field_index = 0, value_index = 0, time_index = 0;
    for(size_t i=0; i<field_num; i++){
        if(v[i] == "_field") field_index = i;
        if(v[i] == "_value") value_index = i;
        if(v[i] == "_time") time_index = i;
    }
    Vibration_t temp;
    temp.device = v_dv->front().device;
    v_dv->clear();
    for(int i=0; i<v.size()/(field_num*16); i++){  //record_num = v.size()/(field_num*16)
        int n = (i+1) * field_num;
        temp.time = v[time_index + n];
        v_dv->push_back(temp);
    }
    int recordIdx[16] = {0};
    for(size_t t=1; t<v.size()/field_num; t++){
        int n = t * field_num;
        if(v[field_index + n] == "_field"){
            continue;
        }else if(v[field_index + n] == "zdSyZdz"){
            (*v_dv)[recordIdx[0]].zdSyZdz = v[value_index + n];
            recordIdx[0]++;
        }else if(v[field_index + n] == "zdSyZxz"){
            (*v_dv)[recordIdx[1]].zdSyZxz = v[value_index + n];
            recordIdx[1]++;
        }else if(v[field_index + n] == "zdSyFfz"){
            (*v_dv)[recordIdx[2]].zdSyFfz = v[value_index + n];
            recordIdx[2]++;
        }else if(v[field_index + n] == "zdSyPjz"){
            (*v_dv)[recordIdx[3]].zdSyPjz = v[value_index + n];
            recordIdx[3]++;
        }else if(v[field_index + n] == "zdSyJfz"){
            (*v_dv)[recordIdx[4]].zdSyJfz = v[value_index + n];
            recordIdx[4]++;
        }else if(v[field_index + n] == "zdSyYxz"){
            (*v_dv)[recordIdx[5]].zdSyYxz = v[value_index + n];
            recordIdx[5]++;
        }else if(v[field_index + n] == "zdSyQdzb"){
            (*v_dv)[recordIdx[6]].zdSyQdzb = v[value_index + n];
            recordIdx[6]++;
        }else if(v[field_index + n] == "zdSyPdzb"){
            (*v_dv)[recordIdx[7]].zdSyPdzb = v[value_index + n];
            recordIdx[7]++;
        }else if(v[field_index + n] == "zdSyYdzb"){
            (*v_dv)[recordIdx[8]].zdSyYdzb = v[value_index + n];
            recordIdx[8]++;
        }else if(v[field_index + n] == "zdPyPpjz"){
            (*v_dv)[recordIdx[9]].zdPyPpjz = v[value_index + n];
            recordIdx[9]++;
        }else if(v[field_index + n] == "zdPyPlzx"){
            (*v_dv)[recordIdx[10]].zdPyPlzx = v[value_index + n];
            recordIdx[10]++;
        }else if(v[field_index + n] == "zdPyJfgpl"){
            (*v_dv)[recordIdx[11]].zdPyJfgpl = v[value_index + n];
            recordIdx[11]++;
        }else if(v[field_index + n] == "zdPyPpjfgz"){
            (*v_dv)[recordIdx[12]].zdPyPpjfgz = v[value_index + n];
            recordIdx[12]++;
        }else if(v[field_index + n] == "zdPyBzcpl"){
            (*v_dv)[recordIdx[13]].zdPyBzcpl = v[value_index + n];
            recordIdx[13]++;
        }else if(v[field_index + n] == "zdYssj"){
            (*v_dv)[recordIdx[14]].zdYssj = v[value_index + n];
            recordIdx[14]++;
        }else if(v[field_index + n] == "zdZcxh"){
            (*v_dv)[recordIdx[15]].zdZcxh = atoi(v[value_index + n].c_str());
            recordIdx[15]++;
        }else{
            printf("未找到指标信息(Fault Data)\n");
        }
    }
    return 0;
}


void Vibration::cleanup(){
    memset(&this->info, 0, sizeof(Vibration_t));
    this->info.device = this->deviceName;
    this->historyInfo.clear();
    this->historyInfo.push_back(this->info);
}

int Vibration::write(){
    //向数据库写入信息
}

int Vibration::show(){
    std::cout << std::endl << "device:" << this->info.device << std::endl;
    std::cout << "time:" <<  this->info.time << std::endl;
    std::cout << "zdSyZdz:" <<  this->info.zdSyZdz << std::endl;
    std::cout << "zdSyZxz:" <<  this->info.zdSyZxz << std::endl;
    std::cout << "zdSyFfz:" <<  this->info.zdSyFfz << std::endl;
    std::cout << "zdSyPjz:" <<  this->info.zdSyPjz << std::endl;
    std::cout << "zdSyJfz:" <<  this->info.zdSyJfz << std::endl;
    std::cout << "zdSyYxz:" <<  this->info.zdSyYxz << std::endl;
    std::cout << "zdSyQdzb:" <<  this->info.zdSyQdzb << std::endl;
    std::cout << "zdSyPdzb:" <<  this->info.zdSyPdzb << std::endl;
    std::cout << "zdSyYdzb:" <<  this->info.zdSyYdzb << std::endl;
    std::cout << "zdPyPpjz:" <<  this->info.zdPyPpjz << std::endl;
    std::cout << "zdPyPlzx:" <<  this->info.zdPyPlzx << std::endl;
    std::cout << "zdPyJfgpl:" <<  this->info.zdPyJfgpl << std::endl;
    std::cout << "zdPyPpjfgz:" <<  this->info.zdPyPpjfgz << std::endl;
    std::cout << "zdPyBzcpl:" <<  this->info.zdPyBzcpl << std::endl;
    std::cout << "zdYssj:" <<  this->info.zdYssj << std::endl;
    std::cout << "zdZcxh:" <<  (this->info.zdZcxh == 0 ? "正常" : "异常") << std::endl;
    for(int i=0; i<this->historyInfo.size(); i++){
        printf("**************historyInfo[%d]******************\n", i);
        std::cout << "device:" << this->historyInfo[i].device << std::endl;
        std::cout << "time:" <<  this->historyInfo[i].time << std::endl;
        std::cout << "zdSyZdz:" <<  this->historyInfo[i].zdSyZdz << std::endl;
        std::cout << "zdSyZxz:" <<  this->historyInfo[i].zdSyZxz << std::endl;
        std::cout << "zdSyFfz:" <<  this->historyInfo[i].zdSyFfz << std::endl;
        std::cout << "zdSyPjz:" <<  this->historyInfo[i].zdSyPjz << std::endl;
        std::cout << "zdSyJfz:" <<  this->historyInfo[i].zdSyJfz << std::endl;
        std::cout << "zdSyYxz:" <<  this->historyInfo[i].zdSyYxz << std::endl;
        std::cout << "zdSyQdzb:" <<  this->historyInfo[i].zdSyQdzb << std::endl;
        std::cout << "zdSyPdzb:" <<  this->historyInfo[i].zdSyPdzb << std::endl;
        std::cout << "zdSyYdzb:" <<  this->historyInfo[i].zdSyYdzb << std::endl;
        std::cout << "zdPyPpjz:" <<  this->historyInfo[i].zdPyPpjz << std::endl;
        std::cout << "zdPyPlzx:" <<  this->historyInfo[i].zdPyPlzx << std::endl;
        std::cout << "zdPyJfgpl:" <<  this->historyInfo[i].zdPyJfgpl << std::endl;
        std::cout << "zdPyPpjfgz:" <<  this->historyInfo[i].zdPyPpjfgz << std::endl;
        std::cout << "zdPyBzcpl:" <<  this->historyInfo[i].zdPyBzcpl << std::endl;
        std::cout << "zdYssj:" <<  this->historyInfo[i].zdYssj << std::endl;
        std::cout << "zdZcxh:" <<  (this->historyInfo[i].zdZcxh == 0 ? "正常" : "异常") << std::endl;
    }
}

void Vibration::check(){
    if(this->info.zdZcxh != 0){
        printf("振动信号异常\t");
        this->isNormal = false;
        //解析当前故障
        this->abnormalPhenomenon = "振动信号异常;";
    }else{
        printf("振动信号正常\t");
        this->isNormal = true;
    }
}

int Vibration::getStatus(){
    //检查返回当前运行状态, 0: 运行, 1: 启动, 2: 停止
    return -1;
}

std::string Vibration::getTime(){
    return this->info.time;
}

size_t Vibration::parseData(void *queriedData, size_t size, size_t nmemb, void *userData){
    // queriedData points to the delivered data, and the size of that data is nmemb; size is always 1.
    size_t realsize = size * nmemb;
    std::string data = std::string(reinterpret_cast<char *>(queriedData), realsize);
    // std::cout << data << std::endl;
    int field_num = 5;
    std::regex line_re("[\n\r,]");
    std::vector<std::string> v(std::sregex_token_iterator(data.begin(), data.end(), line_re, -1), std::sregex_token_iterator());
    for(size_t i=0; i<v.size(); i++){
        if(v[i].empty())
            v.erase(v.begin()+i--);
    }
    Vibration_t *v_d = reinterpret_cast<Vibration_t *>(userData);
    if(v.empty() || v.size() % field_num != 0){
        if(v.empty())
            printf("未找到%s设备数据\n", v_d->device.c_str());
        else 
            printf("%s设备数据格式错误\n", v_d->device.c_str());
        return realsize;
    }
    int field_index = 0, value_index = 0, time_index = 0;
    for(size_t i=0; i<field_num; i++){
        if(v[i] == "_field") field_index = i;
        if(v[i] == "_value") value_index = i;
        if(v[i] == "_time") time_index = i;
    }
    // for(auto&& s: v){
    //     std::cout << "***";
    //     std::cout << s <<  "***" << s.length() << std::endl;
    // }

    for(size_t t=1; t<v.size()/field_num; t++){
        int n = t * field_num;
        if(v[field_index + n] == "_field"){
            continue;
        }else if(v[field_index + n] == "zdSyZdz"){
            v_d->zdSyZdz = v[value_index + n];
        }else if(v[field_index + n] == "zdSyZxz"){
            v_d->zdSyZxz = v[value_index + n];
        }else if(v[field_index + n] == "zdSyFfz"){
            v_d->zdSyFfz = v[value_index + n];
        }else if(v[field_index + n] == "zdSyPjz"){
            v_d->zdSyPjz = v[value_index + n];
        }else if(v[field_index + n] == "zdSyJfz"){
            v_d->zdSyJfz = v[value_index + n];
        }else if(v[field_index + n] == "zdSyYxz"){
            v_d->zdSyYxz = v[value_index + n];
        }else if(v[field_index + n] == "zdSyQdzb"){
            v_d->zdSyQdzb = v[value_index + n];
        }else if(v[field_index + n] == "zdSyPdzb"){
            v_d->zdSyPdzb = v[value_index + n];
        }else if(v[field_index + n] == "zdSyYdzb"){
            v_d->zdSyYdzb = v[value_index + n];
        }else if(v[field_index + n] == "zdPyPpjz"){
            v_d->zdPyPpjz = v[value_index + n];
        }else if(v[field_index + n] == "zdPyPlzx"){
            v_d->zdPyPlzx = v[value_index + n];
        }else if(v[field_index + n] == "zdPyJfgpl"){
            v_d->zdPyJfgpl = v[value_index + n];
        }else if(v[field_index + n] == "zdPyPpjfgz"){
            v_d->zdPyPpjfgz = v[value_index + n];
        }else if(v[field_index + n] == "zdPyBzcpl"){
            v_d->zdPyBzcpl = v[value_index + n];
        }else if(v[field_index + n] == "zdYssj"){
            v_d->zdYssj = v[value_index + n];
        }else if(v[field_index + n] == "zdZcxh"){
            v_d->zdZcxh = atoi(v[value_index + n].c_str());
        }else{
            printf("未找到指标信息\n");
        }
    }
    v_d->time = v[time_index + field_num];
    // printf("v_d.zdZcxh = %d\n", v_d->zdZcxh);
    return realsize;
}

size_t Vibration::parseFaultData(void *queriedData, size_t size, size_t nmemb, void *userData){
    char buffer[10240];
    memset(buffer, 0, sizeof(buffer));
    memcpy(buffer, queriedData, nmemb);
    std::string bufferString(reinterpret_cast<char *>(buffer));
    std::string *historyRawData = reinterpret_cast<std::string *>(userData);
    (*historyRawData) += bufferString;
    return size * nmemb;
}